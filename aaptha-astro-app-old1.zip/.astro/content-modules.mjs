
export default new Map([
['src/data/post/markdown-elements-demo-post.mdx', () => import('astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fdata%2Fpost%2Fmarkdown-elements-demo-post.mdx&astroContentModuleFlag=true')],
['src/data/post/astrowind-template-in-depth.mdx', () => import('astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fdata%2Fpost%2Fastrowind-template-in-depth.mdx&astroContentModuleFlag=true')]]);
		