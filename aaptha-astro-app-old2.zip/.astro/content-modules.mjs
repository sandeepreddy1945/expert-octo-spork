
export default new Map([
['src/data/post/compassionate-caregiver.mdx', () => import('astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fdata%2Fpost%2Fcompassionate-caregiver.mdx&astroContentModuleFlag=true')]]);
		