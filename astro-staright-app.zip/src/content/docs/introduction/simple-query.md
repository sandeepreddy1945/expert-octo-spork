---
title: Simple Query End Points
description: Helps with API's that can deal with XL / CSV files to perform DML Operations on specific Tables
---

## End Points
- /v3/batch-execute

```sql
-- Insert Statements here
```