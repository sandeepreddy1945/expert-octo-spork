---
title: DB Utility API
description: Helps with API's that can deal with XL / CSV files to perform DML Operations on specific Tables
---

The Main Aim of this Utility is to enable the developers to leverage XL / CSV files and perform DML operations on specific tables.

## Currently Supported Operations

- Insert
- Update
- Delete (Beta Phase)

## Supported File Types
- XLSX
- CSV
