---
title: End Points
description: Helps with API's that can deal with XL / CSV files to perform DML Operations on specific Tables
---

## Avilable Mechanisms
- Simple SQL Queries (DML Queries) Via Request Body
- File Upload Request

## How Simple Queries Work's

In this way you provide all the insert statements and add it to a request body. The application would then execute these insert queries in batches of 1000 records once.

## How File Upload Request Work's

In this way you provide the details of the File Path (XL / CSV) in the request body along with the few other details as mentioned here(link here) .