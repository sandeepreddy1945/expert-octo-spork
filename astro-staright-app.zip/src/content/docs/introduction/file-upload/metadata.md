---
title: Metadata
description: Helps with API's that can deal with XL / CSV files to perform DML Operations on specific Tables
---

 

## Supported Formats
- YAML

## Aim of this file
The main aim of this metadata file is support the DML Operations performed.

## What Information does this file provide
This file provides any extra context information that can aid the DML operations performed.

## Use case
- Case where the columns in XL Sheet are having a different name other than the original table column name.
- A default value needs to be provided for a specific column.
- Any context infromation w.r.t the type of the column. Necessary for converting the default type of the column to db supported type.

### Table Attributes

| Field                   | Type    | Nullable | Default | Description                                                                                                                                                                             |
|-------------------------|---------|----------|---------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| name                    | string  | no       | NA      | Table Name on which the DML Operations needs to be performed                                                                                                                            |
| schemaName              | string  | Yes      | NA      | Schema Name of the table if present. Else default schema will be considered.                                                                                                            |


### Column Attributes

| Field          | Type          | Nullable | Default                | Description                                                                                                                                  |
|----------------|---------------|----------|------------------------|----------------------------------------------------------------------------------------------------------------------------------------------|
| name           | string        | No       | NA                     | Original Name of the column taken from Table Name                                                                                            |
| type           | string        | Yes      | NA                     | Data Type of the column. If not provided will be left to the default framework to decide the type                                            |
| mapping        | string        | Yes      | NA                     | The mapping name for the table column to checked in the XL / CSV file. If not provided the DB Table Column and file Column are assumed same. |
| generationType | string (enum) | Yes      | DEFAULT_LONG_TIMESTAMP | Allows the columns of the table to updated / inserted with default system long time.                                                         |
| defaultValue   | string        | Yes      | NA                     | A default value for the column can be provided here. This one works in combination with the generationType attribute VALUE.                  |