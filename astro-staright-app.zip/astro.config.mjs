// @ts-check
import { defineConfig } from "astro/config";
import starlight from "@astrojs/starlight";
import starlightOpenAPI, { openAPISidebarGroups } from "starlight-openapi";

// https://astro.build/config
export default defineConfig({
  integrations: [
    starlight({
      title: "Flex Subscription Inventory",
      social: {
        github: "https://github.com/withastro/starlight",
      },
      plugins: [
        // Generate the OpenAPI documentation pages.
        starlightOpenAPI([
          {
            base: "api",
            label: "Flex Subscription Inventory API",
            schema: "public/schemas/swagger.yaml",
          },
        ]),
      ],
      sidebar: [
        {
          label: "Introduction",
          items: [
            // Each item here is one entry in the navigation menu.
            { label: "Overview", slug: "introduction/overview" },
            { label: "End Points", slug: "introduction/endpoints" },
            { label: "Simple Query", slug: "introduction/simple-query" },
            {
              label: "File Upload",
              items: [
                { label: "Overview", slug: "introduction/file-upload/overview" },
                { label: "Metadata", slug: "introduction/file-upload/metadata" },
              ]
            },
          ],
        },
        {
          label: "Reference",
          autogenerate: { directory: "reference" },
        },
        ...openAPISidebarGroups,
      ],
    }),
  ],
});
