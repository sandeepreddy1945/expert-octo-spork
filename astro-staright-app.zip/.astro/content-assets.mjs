
import __ASTRO_IMAGE_IMPORT_Z2gGaEW from "../../assets/houston.webp?astroContentImageFlag=&importer=src%2Fcontent%2Fdocs%2Findex.mdx";
export default new Map([["../../assets/houston.webp?astroContentImageFlag=&importer=src%2Fcontent%2Fdocs%2Findex.mdx", __ASTRO_IMAGE_IMPORT_Z2gGaEW]]);
		